import java.util.Scanner;

public class ATMInterface {
    private static ATM atm = new ATM();
    private static User currentUser;

    public static void main(String[] args) {
        atm.addUser("user1", new User("user1", "1234", "ACC001", 10000));
        atm.addUser("user2", new User("user2", "5678", "ACC002", 15000));

        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the ATM System");
        while (true) {
            System.out.print("Enter User ID: ");
            String userID = scanner.nextLine();
            System.out.print("Enter PIN: ");
            String pin = scanner.nextLine();

            if (atm.authenticateUser(userID, pin)) {
                currentUser = atm.getUser(userID);
                System.out.println("Login Successful!");

                boolean isFinished = false;
                while (!isFinished) {
                    System.out.println("\n1. Transactions History");
                    System.out.println("2. Withdraw");
                    System.out.println("3. Deposit");
                    System.out.println("4. Transfer");
                    System.out.println("5. Quit");
                    System.out.print("Choose an option: ");
                    int choice = scanner.nextInt();
                    scanner.nextLine(); // consume the newline

                    switch (choice) {
                        case 1:
                            showTransactionHistory();
                            break;
                        case 2:
                            withdraw();
                            break;
                        case 3:
                            deposit();
                            break;
                        case 4:
                            transfer();
                            break;
                        case 5:
                            isFinished = true;
                            System.out.println("Thank you for using the ATM. Goodbye!");
                            break;
                        default:
                            System.out.println("Invalid option. Please try again.");
                    }
                }
            } else {
                System.out.println("Invalid User ID or PIN. Please try again.");
            }
        }
    }

    private static void showTransactionHistory() {
        System.out.println("\nTransaction History:");
        for (String transaction : currentUser.getTransaction().getTransactionHistory()) {
            System.out.println(transaction);
        }
    }

    private static void withdraw() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter amount to withdraw: ");
        float amount = scanner.nextFloat();
        if (currentUser.getAccount().withdraw(amount)) {
            currentUser.getTransaction().addTransaction("Withdrawn: " + amount + " Rs");
            System.out.println("Withdrawal Successful. Remaining Balance: " + currentUser.getAccount().getBalance() + " Rs");
        } else {
            System.out.println("Insufficient Balance.");
        }
    }

    private static void deposit() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter amount to deposit: ");
        float amount = scanner.nextFloat();
        currentUser.getAccount().deposit(amount);
        currentUser.getTransaction().addTransaction("Deposited: " + amount + " Rs");
        System.out.println("Deposit Successful. New Balance: " + currentUser.getAccount().getBalance() + " Rs");
    }

    private static void transfer() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter recipient's User ID: ");
        String recipientID = scanner.nextLine();
        User recipient = atm.getUser(recipientID);

        if (recipient != null) {
            System.out.print("Enter amount to transfer: ");
            float amount = scanner.nextFloat();
            if (currentUser.getAccount().transfer(recipient.getAccount(), amount)) {
                currentUser.getTransaction().addTransaction("Transferred: " + amount + " Rs to " + recipientID);
                recipient.getTransaction().addTransaction("Received: " + amount + " Rs from " + currentUser.getUserID());
                System.out.println("Transfer Successful. Remaining Balance: " + currentUser.getAccount().getBalance() + " Rs");
            } else {
                System.out.println("Insufficient Balance.");
            }
        } else {
            System.out.println("Recipient User ID not found.");
        }
    }
}
